# Hermes Agent 安装指南

## 快速开始

### macOS / Linux

```bash
# 1. 进入目录
cd hermes-share-package

# 2. 安装 uv（Python包管理工具）
curl -LsSf https://astral.sh/uv/install.sh | sh

# 3. 创建虚拟环境并安装依赖
uv venv .venv
source .venv/bin/activate
uv pip install -e .

# 4. 创建配置目录
mkdir -p ~/.hermes

# 5. 复制配置文件并填写 API Key
cp config-examples/config.yaml ~/.hermes/config.yaml
cp config-examples/.env ~/.hermes/.env

# 6. 编辑配置文件，填写你的 API Key
nano ~/.hermes/.env

# 7. 启动仪表板
hermes dashboard
```

### Windows（PowerShell）

```powershell
# 1. 进入目录
cd hermes-share-package

# 2. 安装 uv
Invoke-Expression (Invoke-WebRequest -Uri "https://astral.sh/uv/install.sh" -UseBasicParsing).Content

# 3. 创建虚拟环境并安装依赖
uv venv .venv
.venv\Scripts\activate
uv pip install -e .

# 4. 创建配置目录
mkdir -p $env:LOCALAPPDATA\hermes

# 5. 复制配置文件并填写 API Key
Copy-Item config-examples\config.yaml -Destination $env:LOCALAPPDATA\hermes\config.yaml
Copy-Item config-examples\.env -Destination $env:LOCALAPPDATA\hermes\.env

# 6. 启动仪表板
hermes dashboard
```

## 访问仪表板

启动后在浏览器访问：
- 主页面: http://localhost:9119
- 聊天页面: http://localhost:9119/chat

## 功能特性

- ✅ 多会话窗口（分屏显示）
- ✅ 命令行风格聊天界面
- ✅ 历史会话管理
- ✅ 支持多种模型提供商

## 模型配置

支持的模型提供商：
- DeepSeek (推荐)
- OpenAI
- Anthropic
- Google Gemini
- 以及更多...

## 注意事项

1. 你需要自己注册模型提供商账号获取 API Key
2. 所有数据存储在本地，不会上传到云端
3. 首次启动可能需要下载额外依赖

## 卸载

```bash
# 删除配置目录
rm -rf ~/.hermes

# 删除安装目录
rm -rf hermes-share-package
```
